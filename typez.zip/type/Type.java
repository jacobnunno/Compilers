package type;

abstract public class Type  {
	public static final int VOID = 0;
	public static final int INT = 1;
}
