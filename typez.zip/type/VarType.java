package type;

public class VarType extends Type  {
	public int type;
	
	public VarType(int type) 
	{
			this.type = type;	
	}
}
