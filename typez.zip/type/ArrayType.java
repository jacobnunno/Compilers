package type;


public class ArrayType extends Type  {
	public int type;
	public int length;
	
	public ArrayType(int type, int length) 
	{
			this.type = type;
			this.length = length;	
	}
}
